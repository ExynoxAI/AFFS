// Background Service Worker
console.log("Background service worker loaded");

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log("Background received message:", request, "from sender:", sender);
  
  if (request.action === 'start' || request.action === 'stop' || request.action === 'getStatus') {
    // If message comes from content script, handle it directly
    if (sender.url && sender.url.includes('192.168.1.201:8080')) {
      console.log("Message from content script on correct URL");
      sendResponse({ received: true });
      return true;
    }
    
    // Otherwise, forward message to content script on the current active tab
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs.length > 0) {
        const tabId = tabs[0].id;
        const tabUrl = tabs[0].url;
        console.log("Current tab ID:", tabId, "URL:", tabUrl);
        
        if (!tabUrl.includes('192.168.1.201:8080')) {
          sendResponse({ error: "Not on correct URL" });
          return;
        }
        
        console.log("Forwarding message to tab:", tabId, request);
        
        chrome.tabs.sendMessage(tabId, request, (response) => {
          if (chrome.runtime.lastError) {
            console.error("Error sending to content script:", chrome.runtime.lastError);
            sendResponse({ error: chrome.runtime.lastError.message });
          } else {
            console.log("Content script response:", response);
            sendResponse(response);
          }
        });
      } else {
        sendResponse({ error: "No active tab" });
      }
    });
    
    // Return true to indicate async response
    return true;
  }
});
