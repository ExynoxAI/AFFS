// HyperDyn / Skandan V Combined Auto-Fill Script
console.log("HyperDyn / Skandan V Combined Auto-Fill Script Loaded");

// Check if we're on the correct URL
const currentUrl = window.location.href;
let isRunning = false;
let shouldStop = false;

const isCorrectUrl = currentUrl.includes("192.168.1.201:8080");

if (!isCorrectUrl) {
  console.log("Not on target URL:", currentUrl);
} else {
  console.log("✓ Correct URL detected. Ready to auto-fill.");
}

// Handle messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log("Message received:", request);
  
  if (request.action === 'start') {
    if (!isRunning && isCorrectUrl) {
      isRunning = true;
      shouldStop = false;
      console.log("✓ Auto-fill started from popup");
      sendResponse({ started: true });
      startAutoFill();
    } else if (isRunning) {
      sendResponse({ started: false, message: 'Already running' });
    } else {
      sendResponse({ started: false, message: 'Wrong URL' });
    }
    return true; // Keep channel open for async response
  } else if (request.action === 'stop') {
    shouldStop = true;
    isRunning = false;
    console.log("✓ Auto-fill stopped from popup");
    sendResponse({ stopped: true });
    return true;
  } else if (request.action === 'getStatus') {
    sendResponse({ running: isRunning });
    return true;
  }
});

// Auto-start the script when page loads on correct URL
if (isCorrectUrl) {
  // Wait for page to be fully ready, then auto-start
  const autoStartDelay = setTimeout(() => {
    console.log("Auto-starting auto-fill script...");
    if (!isRunning) {
      isRunning = true;
      shouldStop = false;
      startAutoFill();
    }
  }, 2000); // Wait 2 seconds for page to fully load
}

// Start the auto-fill process
async function startAutoFill() {
  if (!isCorrectUrl) {
    console.error("Cannot start auto-fill: Not on target URL");
    isRunning = false;
    return;
  }

  console.clear();
  console.log("HyperDyn / Skandan V Combined Auto-Fill Script Started");

  try {
  (async function() {
  // -----------------------------
  // Helper functions
  // -----------------------------
  function biasedRandom() {
    const r = Math.random();
    if (r < 0.15) return 1;
    if (r < 0.30) return 2;
    if (r < 0.55) return 3;
    if (r < 0.80) return 4;
    return 5;
  }

  function wait(min, max) {
    return new Promise(resolve => setTimeout(resolve, Math.random() * (max - min) + min));
  }

  async function submitForm(submitButton) {
    if (!submitButton) {
      console.error("Submit button not found!");
      return;
    }
    submitButton.scrollIntoView({ behavior: "smooth", block: "center" });
    await wait(600, 1200);
    submitButton.click();
    console.log("Form submitted.");
    await wait(3000, 5000);
  }

  async function getSubjects(trigger) {
    trigger.click();
    await wait(800, 1500);

    let panel;
    for (let i = 0; i < 10; i++) {
      panel = document.querySelector('div.ui-selectonemenu-panel[style*="display"]');
      if (panel && panel.offsetParent !== null) break;
      await wait(200, 300);
    }

    if (!panel) return [];

    const items = [...panel.querySelectorAll('.ui-selectonemenu-item')]
      .filter(el => el.textContent.trim() && el.textContent.trim() !== "Select One");

    return items;
  }

  async function selectSubject(item) {
    item.scrollIntoView({ behavior: "smooth", block: "center" });
    await wait(400, 900);
    item.click();
    console.log(`Selected subject: ${item.textContent.trim()}`);
    await wait(1500, 2500);
  }

  function fillInputs(selectorPrefix) {
    const inputs = [...document.querySelectorAll(`input[id^="${selectorPrefix}"]`)];
    inputs.forEach((input, index) => {
      const num = biasedRandom();
      input.value = num;
      input.dispatchEvent(new Event('input', { bubbles: true }));
      console.log(`Input ${selectorPrefix}${index + 1}: set to ${num}`);
    });
    return inputs.length;
  }

  // -----------------------------
  // Mid-Term Submission Logic
  // -----------------------------
  async function runMidTerm() {
    console.log("Detected Mid-Term Page. Starting automation...");
    const submitButton = document.querySelector('#k\\:s2');

    while (true) {
      const trigger = document.querySelector('.ui-selectonemenu-trigger.ui-state-default.ui-corner-right');
      if (!trigger) break;

      const items = await getSubjects(trigger);
      if (items.length === 0) break;

      const item = items[0]; // Select first available subject
      await selectSubject(item);

      fillInputs('k:q'); // Fill mid-term inputs

      await submitForm(submitButton);
      console.log("Waiting before next subject...");
      await wait(2000, 4000);
    }

    console.log("Mid-Term automation complete.");
  }

  // -----------------------------
  // End-Sem Submission Logic
  // -----------------------------
  async function runEndSem() {
    console.log("Detected End-Sem Page. Starting automation...");
    const submitButton = document.querySelector('#k\\:s2');

    while (true) {
      const trigger = document.querySelector('.ui-selectonemenu-trigger.ui-state-default.ui-corner-right');
      if (!trigger) break;

      const items = await getSubjects(trigger);
      if (items.length === 0) break;

      const item = items[0]; // Select first available subject
      await selectSubject(item);

      // Fill all three Q&A sections before submitting
      const total1 = fillInputs('k:aq'); // Section 1
      const total2 = fillInputs('k:bq'); // Section 2
      const total3 = fillInputs('k:cq'); // Section 3
      console.log(`Filled ${total1} + ${total2} + ${total3} inputs for current subject.`);

      // Handle additional inner dropdowns if any
      const innerTriggers = [...document.querySelectorAll('.ui-selectonemenu-trigger.ui-state-default.ui-corner-right')]
        .filter(t => !t.closest('.ui-selectonemenu-panel'));
      for (const t of innerTriggers) {
        const innerItems = await getSubjects(t);
        if (innerItems.length > 0) await selectSubject(innerItems[0]);
      }

      // Submit **after all sections are filled**
      await submitForm(submitButton);
      console.log("Waiting before next subject...");
      await wait(2000, 4000);
    }

    console.log("End-Sem automation complete.");
  }

  // Function to check if completion dialog has appeared
  function isCompletionDialogVisible() {
    const dialog = document.querySelector('#primefacesmessagedlg');
    if (!dialog) return false;
    
    const isVisible = dialog.style.display === 'block' || !dialog.classList.contains('ui-hidden-container');
    const messageText = dialog.textContent;
    const isCompleted = messageText.includes('Completed');
    
    return isVisible && isCompleted;
  }

  // Main execution loop - continue until completion dialog appears
  let completionFound = false;
  let maxAttempts = 100; // Safety limit to prevent infinite loops
  let attempts = 0;

  while (!completionFound && attempts < maxAttempts) {
    attempts++;
    
    // Check if user clicked stop
    if (shouldStop) {
      console.log("Auto-fill stopped by user");
      isRunning = false;
      break;
    }
    
    console.log(`Execution cycle ${attempts}...`);

    // Wait for page to fully load
    await wait(1000, 2000);

    // Auto-detect Page Type
    const midTermInputs = document.querySelectorAll('input[id^="k:q"]');
    const endSemInputs = document.querySelectorAll('input[id^="k:aq"], input[id^="k:bq"], input[id^="k:cq"]');

    if (midTermInputs.length > 0) {
      await runMidTerm();
    } else if (endSemInputs.length > 0) {
      await runEndSem();
    } else {
      console.warn("Could not detect Mid-Term or End-Sem page on this attempt.");
      // Wait before checking again
      await wait(2000, 3000);
    }

    // Check if completion dialog has appeared
    await wait(1000, 2000);
    
    if (isCompletionDialogVisible()) {
      completionFound = true;
      console.log("✓ Completion dialog detected! All forms have been successfully submitted.");
      console.log("HyperDyn / Skandan V Combined Automation Finished Successfully!");
      break;
    } else {
      console.log("Completion dialog not yet visible. Checking for more forms...");
    }
  }

  if (!completionFound && !shouldStop) {
    console.warn("Maximum execution cycles reached or completion dialog not found.");
  }

  console.log("HyperDyn / Skandan V Combined Automation Finished.");
  isRunning = false;
  })();
  } catch (error) {
    console.error("Error during auto-fill execution:", error);
    isRunning = false;
  }
}
