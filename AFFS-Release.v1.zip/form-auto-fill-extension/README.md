# Form Auto-Fill Chrome Extension

A Chrome extension that automatically fills exam submission forms with random values on the specified URL.

## Features

- ✅ Automatically detects Mid-Term and End-Semester exam pages
- ✅ Auto-selects subjects from dropdowns
- ✅ Fills input fields with biased random values (1-5)
- ✅ Handles smooth scrolling and natural delays
- ✅ Submits forms automatically
- ✅ Only activates on `http://192.168.1.201:8080/`

## Installation

### Method 1: Load Unpacked (Development)

1. Open Chrome and navigate to `chrome://extensions/`
2. Enable **Developer mode** (toggle in top right)
3. Click **Load unpacked**
4. Navigate to the folder containing this extension
5. Select the folder and click **Open**

### Method 2: Package for Distribution

1. Open `chrome://extensions/`
2. With Developer mode enabled, click **Pack extension**
3. Select this folder as the extension root
4. The extension will be packaged as a `.crx` file

## How It Works

The extension runs automatically when you visit `http://192.168.1.201:8080/`

### Detected Pages:
- **Mid-Term**: Contains inputs with IDs starting with `k:q`
- **End-Semester**: Contains inputs with IDs starting with `k:aq`, `k:bq`, `k:cq`

### Process:
1. Detects the page type automatically
2. Finds and clicks subject dropdown
3. Selects the first available subject
4. Fills all input fields with random values (1-5) with bias towards lower numbers
5. Submits the form
6. Repeats for each subject
7. Waits between subjects (2-4 seconds)

## Configuration

To modify behavior, edit `content.js`:

- **`biasedRandom()`**: Change probability distribution
- **`wait(min, max)`**: Adjust delays between actions (in milliseconds)
- **URL restriction**: Modify the URL check at the top of `content.js`

## Troubleshooting

1. **Extension not running?**
   - Check you're on `http://192.168.1.201:8080/`
   - Open DevTools (F12) and check Console for messages
   - Verify extension is enabled in `chrome://extensions/`

2. **Forms not filling?**
   - Check if page structure matches expected selectors
   - Open Console (F12) to see specific errors
   - Verify form element IDs start with expected prefixes

3. **Modify selectors?**
   - Use browser DevTools to inspect form elements
   - Update selectors in `content.js` accordingly

## Console Output

The extension logs detailed information to the browser console:
```
HyperDyn / Skandan V Combined Auto-Fill Script Started
Detected Mid-Term Page. Starting automation...
Selected subject: Subject Name
Input k:q1: set to 3
Form submitted.
```

## Note

This extension is configured specifically for the exam management system running at `http://192.168.1.201:8080/`. It will not execute on any other URLs.

## License

Created by HyperDyn / Skandan V
