// Popup script for the extension
document.addEventListener('DOMContentLoaded', async () => {
  const startBtn = document.getElementById('startBtn');
  const stopBtn = document.getElementById('stopBtn');
  const status = document.getElementById('status');
  const statusBox = document.getElementById('statusBox');
  const statusDot = document.getElementById('statusDot');
  const urlStatus = document.getElementById('urlStatus');
  
  let isRunning = false;
  let currentTab = null;

  try {
    // Check if we're on the correct URL
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    currentTab = tabs[0];
    
    if (!currentTab) {
      urlStatus.textContent = '✗ No active tab';
      urlStatus.className = 'url-status invalid';
      startBtn.disabled = true;
      return;
    }

    const isCorrectUrl = currentTab.url.includes('192.168.1.201:8080');

    if (isCorrectUrl) {
      urlStatus.innerHTML = '<span>✓</span><span>Ready on correct URL</span>';
      urlStatus.className = 'url-status valid';
      startBtn.disabled = false;
    } else {
      urlStatus.innerHTML = '<span>✗</span><span>Wrong URL detected</span>';
      urlStatus.className = 'url-status invalid';
      startBtn.disabled = true;
    }

    // Start button handler
    startBtn.addEventListener('click', async () => {
      if (isCorrectUrl && currentTab) {
        console.log('Attempting to start auto-fill on tab:', currentTab.id);
        status.textContent = 'Injecting...';
        statusBox.classList.add('active');
        
        try {
          // First, try to inject the content script if it hasn't been loaded yet
          await chrome.scripting.executeScript({
            target: { tabId: currentTab.id },
            files: ['content.js']
          });
          
          console.log('Content script injected successfully');
          
          // Wait a moment for injection to complete
          await new Promise(resolve => setTimeout(resolve, 500));
          
          // Now send the message
          chrome.runtime.sendMessage({ action: 'start' }, (response) => {
            if (chrome.runtime.lastError) {
              console.error('Error:', chrome.runtime.lastError.message);
              status.textContent = 'Error: ' + chrome.runtime.lastError.message;
              statusBox.classList.remove('active');
            } else if (response && response.started) {
              isRunning = true;
              updateUI();
              console.log('✓ Auto-fill started successfully');
            } else if (response && response.error) {
              console.error('Response error:', response.error);
              status.textContent = 'Error: ' + response.error;
              statusBox.classList.remove('active');
            } else {
              console.log('Response:', response);
              isRunning = true;
              updateUI();
            }
          });
        } catch (error) {
          console.error('Injection or message error:', error);
          status.textContent = 'Error: ' + error.message;
          statusBox.classList.remove('active');
        }
      }
    });

    // Stop button handler
    stopBtn.addEventListener('click', () => {
      if (currentTab) {
        chrome.runtime.sendMessage({ action: 'stop' }, (response) => {
          if (chrome.runtime.lastError) {
            console.log('Error:', chrome.runtime.lastError.message);
          } else if (response && response.stopped) {
            isRunning = false;
            updateUI();
            console.log('✓ Auto-fill stopped');
          }
        });
      }
    });

    // Update UI based on running state
    function updateUI() {
      if (isRunning) {
        status.textContent = 'Running...';
        statusDot.innerHTML = '<span class="pulse-dot"></span>';
        statusBox.classList.add('active');
        startBtn.disabled = true;
        stopBtn.disabled = false;
      } else {
        status.textContent = 'Stopped';
        statusDot.textContent = '●';
        statusBox.classList.remove('active');
        startBtn.disabled = !isCorrectUrl;
        stopBtn.disabled = true;
      }
    }

  } catch (error) {
    console.error('Popup error:', error);
    urlStatus.textContent = '✗ Error loading';
    urlStatus.className = 'url-status invalid';
    startBtn.disabled = true;
  }
});
